__turbopack_load_page_chunks__("/_error", [
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
  "static/chunks/node_modules_next_dist_compiled_166120c5._.js",
  "static/chunks/node_modules_next_dist_shared_lib_b4122b32._.js",
  "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
  "static/chunks/node_modules_next_dist_0cccb603._.js",
  "static/chunks/node_modules_next_error_1cfbb379.js",
  "static/chunks/[next]_entry_page-loader_ts_43b523b5._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_db4bb196._.js",
  "static/chunks/[root-of-the-server]__092393de._.js",
  "static/chunks/pages__error_2da965e7._.js",
  "static/chunks/turbopack-pages__error_18aa0e75._.js"
])
