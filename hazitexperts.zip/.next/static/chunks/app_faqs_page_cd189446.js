(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_4757b965._.js",
  "static/chunks/app_faqs_page_fb1c394f.js"
],
    source: "dynamic"
});
