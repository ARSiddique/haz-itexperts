(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/HomeFX.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HomeFX
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
function HomeFX() {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HomeFX.useEffect": ()=>{
            const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
            // ---- once-only reveal
            const nodes = Array.from(document.querySelectorAll("[data-reveal]"));
            const toObserve = nodes.filter({
                "HomeFX.useEffect.toObserve": (n)=>n instanceof HTMLElement && n.dataset.revealed !== "1"
            }["HomeFX.useEffect.toObserve"]);
            const io = new IntersectionObserver({
                "HomeFX.useEffect": (entries)=>{
                    for (const e of entries){
                        const el = e.target;
                        if (!e.isIntersecting || el.dataset.revealed === "1") continue;
                        el.dataset.revealed = "1";
                        if (reduce) {
                            el.style.opacity = "1";
                            el.style.transform = "none";
                        } else if (el.hasAttribute("data-delay")) {
                            el.style.transitionDelay = "".concat(parseFloat(el.getAttribute("data-delay") || "0"), "s");
                        }
                        io.unobserve(el); // one-time
                    }
                }
            }["HomeFX.useEffect"], {
                threshold: 0.16,
                rootMargin: "0px 0px -6% 0px"
            });
            toObserve.forEach({
                "HomeFX.useEffect": (el)=>io.observe(el)
            }["HomeFX.useEffect"]);
            // ---- parallax (cheap)
            const para = Array.from(document.querySelectorAll("[data-parallax]")).filter({
                "HomeFX.useEffect.para": (n)=>n instanceof HTMLElement
            }["HomeFX.useEffect.para"]);
            let raf = 0;
            const tick = {
                "HomeFX.useEffect.tick": ()=>{
                    raf = 0;
                    if (reduce) return;
                    const vpH = window.innerHeight;
                    for (const el of para){
                        const speed = parseFloat(el.getAttribute("data-speed") || "0.12");
                        const r = el.getBoundingClientRect();
                        const mid = r.top + r.height / 2 - vpH / 2;
                        const t = Math.max(-1, Math.min(1, mid / (vpH / 2)));
                        el.style.transform = "translate3d(0, ".concat(t * speed * 60, "px, 0)");
                    }
                }
            }["HomeFX.useEffect.tick"];
            const onScroll = {
                "HomeFX.useEffect.onScroll": ()=>{
                    if (raf) return;
                    raf = requestAnimationFrame(tick);
                }
            }["HomeFX.useEffect.onScroll"];
            tick();
            window.addEventListener("scroll", onScroll, {
                passive: true
            });
            window.addEventListener("resize", onScroll);
            return ({
                "HomeFX.useEffect": ()=>{
                    io.disconnect();
                    window.removeEventListener("scroll", onScroll);
                    window.removeEventListener("resize", onScroll);
                    if (raf) cancelAnimationFrame(raf);
                }
            })["HomeFX.useEffect"];
        }
    }["HomeFX.useEffect"], []);
    return null;
}
_s(HomeFX, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = HomeFX;
var _c;
__turbopack_context__.k.register(_c, "HomeFX");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=components_HomeFX_jsx_85352fbe._.js.map