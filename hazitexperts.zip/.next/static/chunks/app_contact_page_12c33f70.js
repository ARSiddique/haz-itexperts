(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_gsap_0e537b14._.js",
  "static/chunks/_d7bcff02._.js"
],
    source: "dynamic"
});
