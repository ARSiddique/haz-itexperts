(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/Reveal.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HomeFX
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gsap$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/gsap/index.js [app-client] (ecmascript) <locals>");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function HomeFX() {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HomeFX.useEffect": ()=>{
            const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
            // ---- once-only reveal for [data-reveal]
            const els = Array.from(document.querySelectorAll("[data-reveal]")).filter({
                "HomeFX.useEffect.els": (el)=>el instanceof HTMLElement && !el.dataset.revealed
            }["HomeFX.useEffect.els"]);
            const io = new IntersectionObserver({
                "HomeFX.useEffect": (entries)=>{
                    entries.forEach({
                        "HomeFX.useEffect": (e)=>{
                            const el = e.target;
                            if (!e.isIntersecting || el.dataset.revealed === "1") return;
                            el.dataset.revealed = "1";
                            if (reduce) {
                                el.style.opacity = "1";
                                el.style.transform = "none";
                                return;
                            }
                            const dir = el.getAttribute("data-reveal") || "up";
                            const y = dir === "up" ? 16 : dir === "down" ? -16 : 0;
                            const x = dir === "left" ? 16 : dir === "right" ? -16 : 0;
                            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gsap$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["gsap"].fromTo(el, {
                                opacity: 0,
                                x,
                                y
                            }, {
                                opacity: 1,
                                x: 0,
                                y: 0,
                                duration: 0.42,
                                ease: "power2.out"
                            });
                        }
                    }["HomeFX.useEffect"]);
                }
            }["HomeFX.useEffect"], {
                threshold: 0.16
            });
            els.forEach({
                "HomeFX.useEffect": (el)=>io.observe(el)
            }["HomeFX.useEffect"]);
            // ---- parallax (small, cheap, once attached)
            const parallax = Array.from(document.querySelectorAll("[data-parallax]")).filter({
                "HomeFX.useEffect.parallax": (el)=>el instanceof HTMLElement
            }["HomeFX.useEffect.parallax"]);
            let raf = 0;
            const onScroll = {
                "HomeFX.useEffect.onScroll": ()=>{
                    if (raf) return;
                    raf = requestAnimationFrame({
                        "HomeFX.useEffect.onScroll": ()=>{
                            raf = 0;
                            if (reduce) return;
                            const vpH = window.innerHeight;
                            parallax.forEach({
                                "HomeFX.useEffect.onScroll": (el)=>{
                                    const speed = parseFloat(el.getAttribute("data-speed") || "0.12");
                                    const rect = el.getBoundingClientRect();
                                    // element middle relative to viewport
                                    const mid = rect.top + rect.height / 2 - vpH / 2;
                                    const t = Math.max(-1, Math.min(1, mid / (vpH / 2)));
                                    el.style.transform = "translate3d(0, ".concat(t * speed * 60, "px, 0)");
                                }
                            }["HomeFX.useEffect.onScroll"]);
                        }
                    }["HomeFX.useEffect.onScroll"]);
                }
            }["HomeFX.useEffect.onScroll"];
            onScroll();
            window.addEventListener("scroll", onScroll, {
                passive: true
            });
            window.addEventListener("resize", onScroll);
            return ({
                "HomeFX.useEffect": ()=>{
                    io.disconnect();
                    window.removeEventListener("scroll", onScroll);
                    window.removeEventListener("resize", onScroll);
                    if (raf) cancelAnimationFrame(raf);
                }
            })["HomeFX.useEffect"];
        }
    }["HomeFX.useEffect"], []);
    return null;
}
_s(HomeFX, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = HomeFX;
var _c;
__turbopack_context__.k.register(_c, "HomeFX");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=components_Reveal_0fb1a072.js.map