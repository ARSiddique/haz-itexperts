(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_f831d18c._.js",
  "static/chunks/components_HomeFX_jsx_85352fbe._.js"
],
    source: "dynamic"
});
