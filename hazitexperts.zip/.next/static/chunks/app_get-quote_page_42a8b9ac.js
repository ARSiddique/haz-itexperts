(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_2e15f8e3._.js",
  "static/chunks/node_modules_6e7da6fc._.js"
],
    source: "dynamic"
});
