(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_globals_71f961d1.css",
  "static/chunks/_0a46f0ca._.js"
],
    source: "dynamic"
});
