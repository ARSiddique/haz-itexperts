(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_03b8a394._.js",
  "static/chunks/components_Reveal_0fb1a072.js"
],
    source: "dynamic"
});
