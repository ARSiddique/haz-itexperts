(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_gsap_0e537b14._.js",
  "static/chunks/_c27b8b5f._.js"
],
    source: "dynamic"
});
