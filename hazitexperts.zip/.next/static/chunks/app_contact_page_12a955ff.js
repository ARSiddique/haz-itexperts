(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_de1a91ac._.js",
  "static/chunks/components_bc2736e7._.js"
],
    source: "dynamic"
});
