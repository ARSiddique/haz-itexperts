(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_629c5f39._.js",
  "static/chunks/components_9c45f1c3._.js"
],
    source: "dynamic"
});
