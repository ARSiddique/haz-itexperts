(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_10ebad5c._.js",
  "static/chunks/components_9ced4034._.js"
],
    source: "dynamic"
});
