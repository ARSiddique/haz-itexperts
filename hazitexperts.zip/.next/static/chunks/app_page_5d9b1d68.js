(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_7d69dfc8._.js",
  "static/chunks/_520450b0._.js"
],
    source: "dynamic"
});
