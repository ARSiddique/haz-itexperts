module.exports = [
"[project]/app/layout.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=app_layout_5a7e0b9f.js.map