module.exports = [
"[project]/components/Reveal.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HomeFX
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gsap$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/gsap/index.js [app-ssr] (ecmascript) <locals>");
"use client";
;
;
function HomeFX() {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        // ---- once-only reveal for [data-reveal]
        const els = Array.from(document.querySelectorAll("[data-reveal]")).filter((el)=>el instanceof HTMLElement && !el.dataset.revealed);
        const io = new IntersectionObserver((entries)=>{
            entries.forEach((e)=>{
                const el = e.target;
                if (!e.isIntersecting || el.dataset.revealed === "1") return;
                el.dataset.revealed = "1";
                if (reduce) {
                    el.style.opacity = "1";
                    el.style.transform = "none";
                    return;
                }
                const dir = el.getAttribute("data-reveal") || "up";
                const y = dir === "up" ? 16 : dir === "down" ? -16 : 0;
                const x = dir === "left" ? 16 : dir === "right" ? -16 : 0;
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gsap$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["gsap"].fromTo(el, {
                    opacity: 0,
                    x,
                    y
                }, {
                    opacity: 1,
                    x: 0,
                    y: 0,
                    duration: 0.42,
                    ease: "power2.out"
                });
            });
        }, {
            threshold: 0.16
        });
        els.forEach((el)=>io.observe(el));
        // ---- parallax (small, cheap, once attached)
        const parallax = Array.from(document.querySelectorAll("[data-parallax]")).filter((el)=>el instanceof HTMLElement);
        let raf = 0;
        const onScroll = ()=>{
            if (raf) return;
            raf = requestAnimationFrame(()=>{
                raf = 0;
                if (reduce) return;
                const vpH = window.innerHeight;
                parallax.forEach((el)=>{
                    const speed = parseFloat(el.getAttribute("data-speed") || "0.12");
                    const rect = el.getBoundingClientRect();
                    // element middle relative to viewport
                    const mid = rect.top + rect.height / 2 - vpH / 2;
                    const t = Math.max(-1, Math.min(1, mid / (vpH / 2)));
                    el.style.transform = `translate3d(0, ${t * speed * 60}px, 0)`;
                });
            });
        };
        onScroll();
        window.addEventListener("scroll", onScroll, {
            passive: true
        });
        window.addEventListener("resize", onScroll);
        return ()=>{
            io.disconnect();
            window.removeEventListener("scroll", onScroll);
            window.removeEventListener("resize", onScroll);
            if (raf) cancelAnimationFrame(raf);
        };
    }, []);
    return null;
}
}),
];

//# sourceMappingURL=components_Reveal_6f417e82.js.map