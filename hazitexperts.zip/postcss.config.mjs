// postcss.config.mjs
export default {
  plugins: {
    '@tailwindcss/postcss': {}, // ✅ v4 plugin
  },
};
