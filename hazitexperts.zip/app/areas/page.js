// app/areas/page.js
"use client";
import Image from "next/image";

const CITIES = [
  { name: "Lahore", img: "/images/city-lahore.webp" },
  { name: "Karachi", img: "/images/city-karachi.webp" },
  { name: "Islamabad", img: "/images/city-islamabad.webp" },
  { name: "Rawalpindi", img: "/images/city-rawalpindi.webp" },
  { name: "Faisalabad", img: "/images/city-faisalabad.webp" },
  { name: "Multan", img: "/images/city-multan.webp" },
];

export default function AreasPage() {
  return (
    <main className="min-h-screen">
      {/* HERO */}
      <section className="max-w-6xl mx-auto px-4 pt-12 pb-10">
        <p className="text-cyan-300 text-xs font-semibold tracking-wider">Areas we serve</p>
        <h1 className="mt-2 text-3xl md:text-5xl font-extrabold">
          Onsite & remote support across Pakistan’s major cities
        </h1>
        <p className="mt-3 max-w-2xl text-slate-300">
          Lahore se Karachi tak — 24/7 remote helpdesk + scheduled onsite. SLAs aur clear reporting har jaga same.
        </p>
      </section>

      {/* MAP / BANNER */}
      <section className="max-w-6xl mx-auto px-4">
        <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-white/5">
          <Image
            src="/images/areas-banner.webp"
            alt="Pakistan map with major cities"
            width={1600}
            height={900}
            className="w-full h-[260px] md:h-[360px] object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-tr from-[#0b1220]/40 via-transparent to-transparent" />
        </div>
      </section>

      {/* CITIES GRID */}
      <section className="max-w-6xl mx-auto px-4 py-12">
        <h2 className="text-xl md:text-2xl font-semibold">Primary coverage</h2>
        <p className="text-slate-300 text-sm mt-1">
          Same business-day onsite windows in these cities. Nearby towns on request.
        </p>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
          {CITIES.map(c => (
            <div key={c.name} className="group rounded-2xl overflow-hidden border border-white/10 bg-white/5 hover:border-cyan-300/30 transition">
              <div className="relative h-48">
                <Image src={c.img} alt={c.name} fill className="object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                <div className="absolute bottom-3 left-4 text-white text-lg font-semibold drop-shadow">{c.name}</div>
              </div>
              <div className="p-4 text-sm text-slate-300">
                <ul className="list-disc pl-4 space-y-1">
                  <li>Scheduled onsite & emergency dispatch</li>
                  <li>Network, endpoints, servers & cloud</li>
                  <li>Vendor coordination & reporting</li>
                </ul>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* HOW WE DELIVER */}
      <section className="max-w-6xl mx-auto px-4 pb-16 grid md:grid-cols-2 gap-6">
        <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
          <h3 className="text-lg font-semibold">Remote-first, onsite when it matters</h3>
          <p className="text-slate-300 mt-2 text-sm">
            80–90% tickets remote se solve. Hardware, cabling, Wi-Fi surveys, office moves—onsite. P1 targets stay same.
          </p>
          <ul className="list-disc pl-5 mt-4 space-y-1 text-sm text-slate-300">
            <li>Same SLAs across cities</li>
            <li>Change windows after-hours</li>
            <li>Quarterly onsite reviews (vCIO)</li>
          </ul>
        </div>
        <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
          <h3 className="text-lg font-semibold">Industries we support</h3>
          <p className="text-slate-300 mt-2 text-sm">
            Manufacturing, ecommerce, tech, healthcare, services—SMEs with 10–500 users.
          </p>
          <ul className="grid grid-cols-2 gap-2 mt-4 text-sm text-slate-300">
            <li className="rounded-lg border border-white/10 bg-white/5 px-3 py-2">Microsoft 365</li>
            <li className="rounded-lg border border-white/10 bg-white/5 px-3 py-2">Google Workspace</li>
            <li className="rounded-lg border border-white/10 bg-white/5 px-3 py-2">EDR/XDR</li>
            <li className="rounded-lg border border-white/10 bg-white/5 px-3 py-2">MDM</li>
            <li className="rounded-lg border border-white/10 bg-white/5 px-3 py-2">Backup/DR</li>
            <li className="rounded-lg border border-white/10 bg-white/5 px-3 py-2">Networks</li>
          </ul>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-6xl mx-auto px-4 pb-20">
        <div className="rounded-2xl border border-white/10 bg-gradient-to-r from-cyan-500/20 to-fuchsia-500/20 p-6 md:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h3 className="text-xl font-semibold">Your city not listed?</h3>
            <p className="text-slate-200/80">Ping us — we’ll confirm onsite window & remote SLA.</p>
          </div>
          <a href="/get-quote" className="btn-primary">Get Quote</a>
        </div>
      </section>
    </main>
  );
}
