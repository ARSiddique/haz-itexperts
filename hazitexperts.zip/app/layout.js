import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import FABs from "@/components/FABs";
import AutoBot from "@/components/AutoBot";
import BackToTop from "@/components/BackToTop";
import { site } from "@/lib/siteConfig";

export const metadata = {
  title: `${site.name} — Managed IT & Cybersecurity`,
  description: "Managed IT, co-managed IT, and cybersecurity for SMEs in Pakistan.",
};

// ✅ ensures Tailwind breakpoints work on mobile
export const viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="bg-[var(--bg)] text-slate-100 antialiased isolate min-h-screen overflow-x-hidden">
        <Header />
        <main>{children}</main>
        <Footer />

        {/* Global floating helpers */}
       <BackToTop
  size={44}
  chatSize={56}
  gap={12}
  mode="hide"     // ⬅️ chat open -> hide
  panelLift={360} // safety (panel ~19–22rem). adjust if needed
  z={80}          // ⬅️ panel (z=85) se neeche
/>
        <AutoBot />
        <FABs />
      </body>
    </html>
  );
}
