// app/faqs/page.js
"use client";
import Image from "next/image";
import { useEffect } from "react";
import { ChevronDown } from "lucide-react";
import * as Accordion from "@radix-ui/react-accordion";

function Q({ id, q, a }) {
  return (
    <Accordion.Item value={id} className="border-b border-white/10">
      <Accordion.Header>
        <Accordion.Trigger className="group w-full py-4 text-left flex items-center justify-between gap-4">
          <span className="text-base font-medium">{q}</span>
          <ChevronDown className="h-4 w-4 shrink-0 transition-transform group-data-[state=open]:rotate-180" />
        </Accordion.Trigger>
      </Accordion.Header>
      <Accordion.Content className="pb-5 text-slate-300 data-[state=open]:animate-slideDown data-[state=closed]:animate-slideUp">
        {a}
      </Accordion.Content>
    </Accordion.Item>
  );
}

export default function FAQsPage() {
  useEffect(() => { window.scrollTo(0, 0); }, []);

  return (
    <main className="min-h-screen">
      {/* HERO */}
      <section className="max-w-6xl mx-auto px-4 pt-12 pb-8">
        <p className="text-cyan-300 text-xs font-semibold tracking-wider">FAQs</p>
        <h1 className="mt-2 text-3xl md:text-5xl font-extrabold">
          Answers to the things clients ask most
        </h1>
        <p className="mt-3 max-w-2xl text-slate-300">
          Managed IT, security, SLAs, tooling—sab cheezen yahan detail me. Agar
          phir bhi koi sawal reh jaye, <span className="text-cyan-300">Get Quote</span> se ping kar do.
        </p>
      </section>

      {/* INTRO IMAGE */}
      <section className="max-w-6xl mx-auto px-4">
        <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-white/5">
          <Image
            src="/images/faq-hero.webp" // put your image in /public/images/
            alt="Knowledgebase and Q&A"
            width={1600}
            height={900}
            className="w-full h-[280px] md:h-[360px] object-cover opacity-90"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-tr from-[#0b1220]/40 via-transparent to-transparent" />
        </div>
      </section>

      {/* ACCORDIONS */}
      <section className="max-w-6xl mx-auto px-4 py-12 grid lg:grid-cols-3 gap-8">
        {/* left column visuals */}
        <div className="lg:col-span-1 space-y-6">
          <div className="relative rounded-2xl overflow-hidden border border-white/10 bg-white/5">
            <Image
              src="/images/faq-security.webp"
              alt="Security workflow"
              width={900}
              height={700}
              className="w-full h-64 object-cover"
            />
          </div>
          <div className="relative rounded-2xl overflow-hidden border border-white/10 bg-white/5">
            <Image
              src="/images/faq-helpdesk.webp"
              alt="Helpdesk dashboards"
              width={900}
              height={700}
              className="w-full h-64 object-cover"
            />
          </div>
        </div>

        {/* right column FAQs */}
        <div className="lg:col-span-2">
          <Accordion.Root type="multiple" className="rounded-2xl border border-white/10 bg-white/5 px-4 md:px-6">
            <Q
              id="what-included"
              q="Managed IT plan me exactly kya include hota hai?"
              a={
                <ul className="list-disc pl-5 space-y-1">
                  <li>24/7 helpdesk (P1 ≤ 15 min response)</li>
                  <li>Patch/Update management (OS + apps)</li>
                  <li>Endpoint security: EDR/XDR + ransomware protection</li>
                  <li>Email security (MFA/SSO, phishing defense)</li>
                  <li>MDM for Windows/Mac/iOS/Android</li>
                  <li>Microsoft 365 / Google Workspace admin</li>
                  <li>Backup & DR (endpoints + M365/Google)</li>
                  <li>Network monitoring (Wi-Fi, switches, firewalls)</li>
                  <li>vCIO: quarterly roadmap, budget & KPIs</li>
                </ul>
              }
            />
            <Q
              id="pricing"
              q="Pricing kaise decide hota hai?"
              a="Hum per-user, per-device ya hybrid model use karte hain — complexity aur scope ke hisaab se. SME ke liye fixed monthly fee so aapko cost predictability milti hai."
            />
            <Q
              id="tools"
              q="Aap ka tooling stack kya hota hai?"
              a="Industry-standard EDR/XDR, RMM, MDM, secure email gateway, backup/DR, SIEM-ready logging. Exact vendors engagement ke waqt disclose hote hain."
            />
            <Q
              id="security"
              q="Security posture kaise improve karwate ho?"
              a="Baseline hardening + MFA/SSO, endpoint protection, email filtering, least-privilege access, patch SLAs, 3-2-1 backups, aur measurable KPIs per quarter."
            />
            <Q
              id="migration"
              q="Microsoft 365/Google migration me downtime?"
              a="Zero-loss approach: staged cutovers, mailbox delta syncs, endpoint prep aur change comms — downtime minimal rakha jata hai."
            />
            <Q
              id="onboarding"
              q="Onboarding kitne dino me?"
              a="Discovery + stabilization sprint first 2–4 weeks, phir continuous ops & improvements. Critical gaps pehle 7–10 days me close kar dete hain."
            />
            <Q
              id="comanaged"
              q="Co-managed IT possible?"
              a="Bilkul. Hum aapke in-house IT ko augment karte hain: after-hours coverage, escalations, projects, monitoring & reporting."
            />
          </Accordion.Root>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-6xl mx-auto px-4 pb-16">
        <div className="rounded-2xl border border-white/10 bg-gradient-to-r from-cyan-500/20 to-fuchsia-500/20 p-6 md:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h3 className="text-xl font-semibold">Still have a question?</h3>
            <p className="text-slate-200/80">DM on WhatsApp or request a quick assessment — free.</p>
          </div>
          <a href="/get-quote" className="btn-primary">Get Quote</a>
        </div>
      </section>
    </main>
  );
}

/** Tailwind helpers (global.css or components.css)
@keyframes slideDown { from { height:0; opacity:0 } to { height:var(--radix-accordion-content-height); opacity:1 } }
@keyframes slideUp   { from { height:var(--radix-accordion-content-height); opacity:1 } to { height:0; opacity:0 } }
.data-\[state\=open\]\:animate-slideDown { animation: slideDown .22s ease-out }
.data-\[state\=closed\]\:animate-slideUp { animation: slideUp .18s ease-in }
.btn-primary { @apply rounded-lg px-5 py-3 font-semibold border border-cyan-300/30 text-cyan-300 bg-cyan-400/10 hover:bg-cyan-400/20 transition }
*/
