"use client";
import { useEffect } from "react";

/**
 * Lightweight effects:
 * - One-time reveal on [data-reveal] (CSS transitions)
 * - Cheap parallax on [data-parallax] with data-speed
 * - Respects prefers-reduced-motion
 */
export default function HomeFX() {
  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    // ---- once-only reveal
    const nodes = Array.from(document.querySelectorAll("[data-reveal]"));
    const toObserve = nodes.filter((n) => n instanceof HTMLElement && n.dataset.revealed !== "1");

    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          const el = e.target;
          if (!e.isIntersecting || el.dataset.revealed === "1") continue;
          el.dataset.revealed = "1";
          if (reduce) {
            el.style.opacity = "1";
            el.style.transform = "none";
          } else if (el.hasAttribute("data-delay")) {
            el.style.transitionDelay = `${parseFloat(el.getAttribute("data-delay") || "0")}s`;
          }
          io.unobserve(el); // one-time
        }
      },
      { threshold: 0.16, rootMargin: "0px 0px -6% 0px" }
    );

    toObserve.forEach((el) => io.observe(el));

    // ---- parallax (cheap)
    const para = Array.from(document.querySelectorAll("[data-parallax]")).filter(
      (n) => n instanceof HTMLElement
    );

    let raf = 0;
    const tick = () => {
      raf = 0;
      if (reduce) return;
      const vpH = window.innerHeight;
      for (const el of para) {
        const speed = parseFloat(el.getAttribute("data-speed") || "0.12");
        const r = el.getBoundingClientRect();
        const mid = r.top + r.height / 2 - vpH / 2;
        const t = Math.max(-1, Math.min(1, mid / (vpH / 2)));
        el.style.transform = `translate3d(0, ${t * speed * 60}px, 0)`;
      }
    };
    const onScroll = () => {
      if (raf) return;
      raf = requestAnimationFrame(tick);
    };

    tick();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);

    return () => {
      io.disconnect();
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  return null;
}
