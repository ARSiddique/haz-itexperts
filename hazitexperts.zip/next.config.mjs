/** @type {import('next').NextConfig} */
const nextConfig = {
  devIndicators: false, // <- hides the “N” badge & build indicator in dev
};

export default nextConfig;
