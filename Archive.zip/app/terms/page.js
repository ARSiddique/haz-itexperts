export const metadata = { title: "Terms | Supreme IT Experts" };
export default function Page() {
  return (
    <main style={{maxWidth:900,margin:"0 auto",padding:24,lineHeight:1.6}}>
      <h1>Terms</h1>
      <p>Services are provided under a separate agreement or statement of work.
      Website content is for information only and may change without notice.</p>
    </main>
  );
}
